package com.example.lockscreen;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final int ADMIN_CODE=11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }
    public void setSCreenOff(final Context context){
        DevicePolicyManager devicePolicyManager=(DevicePolicyManager)context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName adminName=new ComponentName(context,SecondAdmin.class);
        boolean isActive=devicePolicyManager.isAdminActive(adminName);
        if(isActive){
            devicePolicyManager.lockNow();
        }else {
            Intent intent=new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,adminName);
            startActivityForResult(intent,ADMIN_CODE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        switch (requestCode){
            case ADMIN_CODE:
                if(resultCode== Activity.RESULT_OK){
                    Toast.makeText(getApplicationContext(),"Admin Approved",Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(getApplicationContext(),"Admin Not Approved",Toast.LENGTH_LONG).show();
                }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }
}